﻿

Public Class Form1
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub lsbPrices_DoubleClick(sender As Object, e As EventArgs) Handles lsbPrices.DoubleClick

        Dim strUserInput As String

        strUserInput = Microsoft.VisualBasic.InputBox("Add a number", "Enter Candy Price")
        If strUserInput <> "" Then
            lsbPrices.Items.Add(strUserInput)
        Else
            MessageBox.Show("No input")
        End If
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim temp As Double = 0
        Dim items As Double
        Dim x As Integer = lsbPrices.Items.Count - 1
        For i As Integer = 0 To x Step 1
            Double.TryParse(lsbPrices.Items(i).ToString, items)
            temp = temp + items
        Next




        txtSubtotal.Text = CType(temp, String)

    End Sub
End Class
